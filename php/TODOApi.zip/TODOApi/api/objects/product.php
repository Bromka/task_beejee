<?php
class Product
{

    // database connection and table name
    private $conn;
    private $table_name = "tasklist";

    // object properties
    public $id;
    public $name;
    public $email;
    public $description;
    public $created;
    public $modifed;
    public $taskdone;

    // constructor with $db as database connection
    public function __construct($db)
    {
        $this->conn = $db;
    }

    // read products
    function read($data)
    {
        $sortAsc = $data->sortAsc;
        $sortType = $data->sortType;

        if ($sortType == 'sortByName') {
            $sortTypeInQuery = 'name';
        } elseif ($sortType == 'sortByEmail') {
            $sortTypeInQuery = 'email';
        } else {
            $sortTypeInQuery = 'taskdone';
        }

        $limitStart = ($data->page - 1) * 3;
        $limit = $data->itemsOnPage;

        $sortDest = ($sortAsc == true) ? 'ASC' : 'DESC';

        // select all query
        $query = "SELECT
                p.id, p.name, p.description,  p.created, p.email, p.modifed, p.taskdone
            FROM
                " . $this->table_name . " p
         
            ORDER BY
                p." . $sortTypeInQuery . " " . $sortDest . " LIMIT " . $limitStart . ", " . $limit . "";

        // prepare query statement
        $stmt = $this->conn->prepare($query);

        // execute query
        $stmt->execute();

        return $stmt;
    }

    function edit($data)
    {
        $taskdone = $data->taskDone ? '1' : 'null';
        $query = "UPDATE " . $this->table_name . " 
        SET description = '" . $data->taskDescription . "', taskdone=".$taskdone." WHERE id=". $data->taskID ."";
        $stmt2 = $this->conn->prepare($query);

        // execute query
        $stmt2->execute();
        return $stmt2;
    }

    //getCount
    function getCountOfRecords()
    {

        // select all query
        $query = "SELECT COUNT(*) as count
            FROM
                " . $this->table_name . "";

        // prepare query statement
        $stmt2 = $this->conn->prepare($query);

        // execute query
        $stmt2->execute();
        return $stmt2;
    }

    // create product
    function create()
    {

        // query to insert record
        $query = "INSERT INTO
                " . $this->table_name . "
            SET
                name=:name, email=:email, description=:description, created=:created";

        // prepare query
        $stmt = $this->conn->prepare($query);

        // sanitize
        $this->name = htmlspecialchars(strip_tags($this->name));
        $this->email = htmlspecialchars(strip_tags($this->email));
        $this->description = htmlspecialchars(strip_tags($this->description));
        $this->created = htmlspecialchars(strip_tags($this->created));

        // bind values
        $stmt->bindParam(":name", $this->name);
        $stmt->bindParam(":email", $this->email);
        $stmt->bindParam(":description", $this->description);
        $stmt->bindParam(":created", $this->created);

        // execute query
        if ($stmt->execute()) {
            return true;
        }

        return false;
    }
}
