<?php
// required headers
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: *');
header('Access-Control-Allow-Headers: content-type');

// database connection will be here

// include database and object files
include_once '../config/database.php';
$dataRec = json_decode(file_get_contents("php://input"));
if ($dataRec->userName == 'admin' && $dataRec->userPassword=='123'){
    $request = "Administrator";
} else {
    $request = "Unknown_user";
}

echo json_encode($request, JSON_FORCE_OBJECT);